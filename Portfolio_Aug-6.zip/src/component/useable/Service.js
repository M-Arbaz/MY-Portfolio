import React from 'react'

export default function Service() {
  return (
    <div>
      service
    </div>
  )
}
